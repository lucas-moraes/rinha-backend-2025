export interface CreatePaymentDto {
  correlationId: string;
  amount: number;
}
