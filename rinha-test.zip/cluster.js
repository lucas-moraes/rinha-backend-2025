import cluster from "cluster";
import os from "os";
import { buildApp } from "./app";
import { CONFIG } from "./config";

if (cluster.isMaster) {
  const cpus = os.cpus().length;
  console.log(`Master PID ${process.pid} iniciando ${cpus} workers...`);
  for (let i = 0; i < cpus; i++) cluster.fork();

  cluster.on("exit", (worker, code, signal) => {
    console.warn(`Worker ${worker.process.pid} caiu (${signal}), recriando…`);
    cluster.fork();
  });
} else {
  // cada fork executa exatamente o Fastify
  async function start() {
    const app = buildApp();
    await app.listen({
      port: CONFIG.PORT,
      host: "0.0.0.0", // <— isso é fundamental!
    });
    console.log(`🚀 Worker ${process.pid} ouvindo em 0.0.0.0:${CONFIG.PORT}`);
  }

  start().catch((err) => {
    console.error("Erro no Fastify:", err);
    process.exit(1);
  });
}
